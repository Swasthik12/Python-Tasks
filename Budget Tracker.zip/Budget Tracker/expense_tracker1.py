from expense import Expense

def main():
    print(f"Running Expense Tracker!")
    expense_file_path = "expense.csv"

    # get user input for expense
    expense = get_user_expense()
    print(expense)

    # write their expense to a file.
    save_expense_to_file(expense, expense_file_path)

    # read file and summarize expense.
    summarize_expenses(expense_file_path)

def get_user_expense():
    print(f"Getting User expense")
    expense_name = input("enter expense name")
    expense_amount = float(input("enter expense amount"))
    print(f"You have entered {expense_name}, {expense_amount}")

    expense_categories = [
        "Food",
        "Home",
        "Work",
        "Fun",
        "Misc",
    ]

    while True:
        print("Select a category:")
        for i, category_name in enumerate(expense_categories):
            print(f"{i + 1}.{category_name}")

        value_range = f"[1 - {len(expense_categories)}]"
        selected_index = int(input(f"enter a category number {value_range}:")) - 1

        if selected_index in range(len(expense_categories)):
            selected_category = expense_categories[selected_index]
            new_expense = Expense(name=expense_name, category=selected_category, amount=expense_amount)
            return new_expense
        else:
            print("Invalid category. Please try again")

def save_expense_to_file(expense: Expense, expense_file_path):
    print(f"Saving User expense: {expense} to {expense_file_path}")
    with open(expense_file_path, "a") as f:
        f.write(f"{expense.name},{expense.amount},{expense.category}\n")

def summarize_expenses(expense_file_path):
    print(f"Summarizing User expense")

if __name__ == "__main__":
    main()
 